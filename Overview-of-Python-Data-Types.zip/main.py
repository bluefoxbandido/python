#Single Data Types
	# Booleans
	# Numbers
		#Int 
		#Float
	# Strings
	# Bytes and Byte Arrays
	# None

#Data Structures and Data Collections
	# Lists
	# Tuples
	# Sets
	# Dictionaries

meal_completed = True
sub_total = 100
tip = sub_total * 1/5

total = sub_total + tip
receipt = "Your total is " + str(total)
print(receipt)