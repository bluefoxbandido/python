api_data = '5'
greeting = 'Hi'

print(api_data.isalpha())
print(greeting.isalpha())

print(':bluefox.do(devops)')
print(':bluefox.do()')