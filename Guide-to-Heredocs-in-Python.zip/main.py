# Heredoc

content = """
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
""".strip()
print(content)