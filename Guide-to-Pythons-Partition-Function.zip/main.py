heading = "Python: An Introduction"

header, _, subheader = heading.partition(': ')

print(header)
print(_)
print(subheader)