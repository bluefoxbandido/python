# Heredoc

content = """
content 
content content
content content content
content content content content 
content content content content content 
content content content content content content 
content content content content content content content content 
content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
content content content content content content content content
"""
print(repr((content)))