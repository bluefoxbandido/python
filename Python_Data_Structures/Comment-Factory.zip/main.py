#Single Line Comment 

name = 'Adam Parker' # ToDo: Split into two variables || Inline Comment

"""
hello 
hello
this is a multi line comment in action
"""

# psuedo = 'code'