#The quick brown fox jumps over the lazy dog
# T => 0
# H => 1
# E => 2
# ' ' => 3
sentence = 'The quick brown fox jumps over the lazy dog'
first = sentence[0]
second = sentence[1]
third = sentence[2]

the = first + second + third
print(the)

first_word = sentence[0:3]
print(first_word)

print('Thy' + sentence[3:])

