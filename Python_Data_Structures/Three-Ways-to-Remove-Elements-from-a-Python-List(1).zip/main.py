users = ['Kristine', 'Tiffany', 'Jordan']

print(users)

users.remove('Jordan')

print(users)

popped_user = users.pop()

print(users)
print(popped_user)

del users[0]
print(users)