users = ['Kristine', 'Tiffany', 'Jordan']

ids = [1, 2, 3, 4]

mixed_list = [42, 10.3, 'Altuve', users ]

print(mixed_list)

user_list = mixed_list.pop()

print(user_list)
print(mixed_list)