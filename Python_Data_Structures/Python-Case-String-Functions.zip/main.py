# sentence = 'The quick brown forx jumped'.upper()
# print(sentence)

# sentence2 = 'The quick brown fox jumped'
# print(sentence2.upper())
# print(sentence2)

# sentence_caps = sentence2.upper()
# print(sentence_caps)

# sentence = 'the quick brown fox jumped'.title()
# print(sentence)

sentence = 'THE QUICK BROWN FOX JUMPED'.lower()
print(sentence)