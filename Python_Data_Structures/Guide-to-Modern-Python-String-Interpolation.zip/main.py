name = 'adam'
product = 'Python eLearning Course'

email_content = f"""
Hi {name}

Thank you for purchasing {product}

Regards,
	Sales Team
"""
print(email_content)

