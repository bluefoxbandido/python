# meal_completed = True
# total = 100
# tip = total * 1/5

# total = total + tip
# receipt = "Your total is " + str(total)
# print(receipt)

first = 'Springer'
second = 'Bregman'
third = 'Altuve'
print(second)
second = 'Correa'
print(second)

print(first)
first = second
print(first)

#You can reassign values to already declared variables, OOP yeah you know me.