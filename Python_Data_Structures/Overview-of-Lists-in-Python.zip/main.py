"""
User Database Query
Kristine
Tiffany
Jordan
"""
users = ['Kristine', 'Tiffany', 'Jordan']
print(users)

users.insert(0, 'Anthony')
print(users)

users.append('ian')

print(users)


print(users[2])
users[4] = 'brayden'
print(users)