sentence = 'The quick brown fox jumped over the lazy dog'

sentence_two = "That is my dog's bowl"

sentence_three = ' "Where are they going?" '

sentence_four = 'That is my dog\'s bowl'

print(sentence, sentence_two, sentence_three, sentence_four)